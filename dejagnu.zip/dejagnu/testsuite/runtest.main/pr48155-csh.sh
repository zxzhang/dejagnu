#!/bin/sh

cat <<EOF 1>&2
timestamp=2021-01-25: Command not found.
Illegal variable name.
EOF

exit 1
